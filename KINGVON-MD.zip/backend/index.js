const express = require("express");
const { Client, LocalAuth } = require("whatsapp-web.js");
const qrcode = require("qrcode");
const fs = require("fs");
const cors = require("cors");
const app = express();
const PORT = process.env.PORT || 5000;

app.use(cors());
app.use(express.json());

let bots = {};

app.post("/start", async (req, res) => {
  const userId = req.body.userId;
  const config = req.body.config;

  if (!userId) return res.status(400).send("User ID required");

  if (bots[userId]) return res.send({ status: "already running" });

  const client = new Client({
    authStrategy: new LocalAuth({ clientId: userId }),
    puppeteer: { headless: true }
  });

  bots[userId] = { client, config };

  client.on("qr", (qr) => {
    qrcode.toDataURL(qr, (err, url) => {
      fs.writeFileSync(`./qr_${userId}.txt`, url);
    });
  });

  client.on("ready", () => {
    console.log(`${userId} bot is ready.`);
    fs.writeFileSync(`./ready_${userId}.txt`, "ready");
  });

  client.on("message", async (message) => {
    const { config } = bots[userId];
    if (config.autoReply && message.body === ".ping") {
      await message.reply("pong");
    }
    if (config.gptMenu && message.body.startsWith(".gpt")) {
      message.reply("[GPT Response Placeholder]");
    }
  });

  client.initialize();
  res.send({ status: "starting" });
});

app.get("/qr/:userId", (req, res) => {
  const file = `./qr_${req.params.userId}.txt`;
  if (fs.existsSync(file)) {
    const qr = fs.readFileSync(file, "utf-8");
    res.send({ qr });
  } else {
    res.status(404).send("QR not generated yet");
  }
});

app.listen(PORT, () => console.log(`Backend running on http://localhost:${PORT}`));
