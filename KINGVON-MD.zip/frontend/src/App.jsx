import { useEffect, useState } from "react";
import axios from "axios";

export default function App() {
  const [userId, setUserId] = useState("testuser");
  const [qr, setQr] = useState("");
  const [loading, setLoading] = useState(false);
  const [config, setConfig] = useState({
    autoReply: false,
    groupAdmin: false,
    aiChatbot: false,
    mediaBot: true,
    utilityBot: true,
    autoViewStatus: false,
    autoReactStatus: false,
    autoReactMessage: false,
    gptMenu: true
  });

  const startBot = async () => {
    setLoading(true);
    await axios.post("http://localhost:5000/start", { userId, config });
    fetchQR();
  };

  const fetchQR = async () => {
    const interval = setInterval(async () => {
      try {
        const res = await axios.get(`http://localhost:5000/qr/${userId}`);
        setQr(res.data.qr);
        clearInterval(interval);
      } catch {}
    }, 2000);
  };

  return (
    <div className="min-h-screen bg-gray-900 text-white p-6 font-sans">
      <h1 className="text-3xl font-bold mb-4">KINGVON-MD Dashboard</h1>

      <div className="grid grid-cols-2 gap-4 mb-6">
        {Object.keys(config).map((key) => (
          <label key={key} className="flex items-center space-x-2">
            <input
              type="checkbox"
              checked={config[key]}
              onChange={(e) =>
                setConfig({ ...config, [key]: e.target.checked })
              }
            />
            <span className="capitalize">{key.replace(/([A-Z])/g, " $1")}</span>
          </label>
        ))}
      </div>

      <button
        onClick={startBot}
        className="bg-blue-600 hover:bg-blue-700 px-4 py-2 rounded shadow"
      >
        Start Bot
      </button>

      {qr && (
        <div className="mt-6">
          <h2 className="text-xl mb-2">Scan QR Code:</h2>
          <img src={qr} alt="QR Code" className="w-64 h-64" />
        </div>
      )}

      {loading && !qr && <p className="mt-4">Waiting for QR code...</p>}
    </div>
  );
}
